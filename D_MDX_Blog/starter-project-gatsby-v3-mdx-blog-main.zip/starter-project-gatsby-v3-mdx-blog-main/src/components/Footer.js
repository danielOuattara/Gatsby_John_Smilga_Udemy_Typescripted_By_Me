import React from 'react'
import SocialLinks from '../constants/socialLinks'
const Footer = () => {
  return (
    <h4>footer component</h4>
  )
}

export default Footer
