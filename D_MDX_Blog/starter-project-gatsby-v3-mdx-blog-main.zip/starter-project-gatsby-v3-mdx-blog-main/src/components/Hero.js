import React from 'react'
import { StaticImage } from 'gatsby-plugin-image'

const Hero = () => {
  return (
    <h4>hero component</h4>
  )
}

export default Hero
