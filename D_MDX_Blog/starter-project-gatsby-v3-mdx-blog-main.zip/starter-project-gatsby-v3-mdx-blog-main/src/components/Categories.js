import React from 'react'
import { graphql, useStaticQuery } from 'gatsby'
import { Link } from 'gatsby'


const Categories = () => { 
  return <h4>categories component</h4>
}

export default Categories
