import React from 'react'
import Links from '../constants/links'
import Categories from '../components/Categories'
import { IoMdClose } from 'react-icons/io'

const Sidebar = () => {
  return (
    <h4>sidebar component</h4>
  )
}

export default Sidebar
