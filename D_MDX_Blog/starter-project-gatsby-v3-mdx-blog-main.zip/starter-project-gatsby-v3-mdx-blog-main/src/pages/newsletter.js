import React from 'react'
import Layout from '../components/Layout'
const NewsLetter = () => {
  return (
    <h4>newsletter</h4>
  )
}

export default NewsLetter
